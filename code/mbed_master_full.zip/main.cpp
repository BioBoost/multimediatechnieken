#include "mbed.h"
#include <assert.h>

DigitalOut aLED(LED1);
Serial pc(USBTX, USBRX); // tx, rx
I2C i2c(p28, p27);

const int SLAVE_ADDRESS = 0x84;
const int MEMORY_SIZE = 32;
const int I2C_FREQUENCY = 100000;
const int I2C_BUFFER_SIZE = 6;

enum COMMAND { PUSH, PULL, CLEAR, PRINT };

#define intToByte(pbytebuff,intval) (*((int*)(pbytebuff)) = intval)
#define byteToInt(pbytebuff,pintval) (*(pintval) = *((int*)(pbytebuff)))

/*
 * Send an integer value to the slave memory 
 * and store it at address.
 *
 * @return 0 on success
 */
int pushToMemory(int value, int address)
{
    char buffer[I2C_BUFFER_SIZE];

    buffer[0] = PUSH;
    buffer[1] = address;
    intToByte(buffer+2, value);
    return i2c.write(SLAVE_ADDRESS, buffer, 6);  // 0 on success
}

int pullFromMemory(int * pvalue, int address)
{
    char buffer[I2C_BUFFER_SIZE];

    buffer[0] = PULL;
    buffer[1] = address;
    int success = i2c.write(SLAVE_ADDRESS, buffer, 2);  // 0 on success
    wait(0.1);
    success = i2c.read(SLAVE_ADDRESS, buffer, 5) && success;  // 0 on success
    byteToInt(buffer+1, pvalue);
    
    return success;
}

int printMemory(void)
{
    char buffer[I2C_BUFFER_SIZE];
    buffer[0] = PRINT;
    return i2c.write(SLAVE_ADDRESS, buffer, 1);  // 0 on success
}

int clearMemory(void)
{
    char buffer[I2C_BUFFER_SIZE];
    buffer[0] = CLEAR;
    return i2c.write(SLAVE_ADDRESS, buffer, 1);  // 0 on success
}


/*
 * Perfom diagnostic
 */
bool performDiagnostic(void)
{
    int values[MEMORY_SIZE];
    
    // Create random value
    srand(time(NULL));
    for (int i = 0; i < MEMORY_SIZE; i++) {
        values[i] = rand() % 1000;
    }
    
    // Send all values to i2c slave
    for (int i = 0; i < MEMORY_SIZE; i++) {
        if (!pushToMemory(values[i], i)) {
            pc.printf("!");
        } else {
            pc.printf("x");
        }     
        fflush(stdout);
        wait(0.1);
    }
    pc.printf("\r\n");
    fflush(stdout);
    wait(2);
    // Read all values from the i2c slave
    bool success = true;
    for (int i = 0; i < MEMORY_SIZE; i++) {
        int value = 0;
        if (!pullFromMemory(&value, i)) {
            if (value == values[i]) {
                pc.printf("!");
            } else {
                pc.printf("?");
                success = false;
            }
        } else {
            pc.printf("x");
            success = false;
        }     
        fflush(stdout);
        wait(0.1);
    }
    pc.printf("\r\n");
    return success;
}

int main() {
    pc.baud(115200);
    pc.printf("I am the master device\r\n");
    pc.printf("Size of integer is %d bytes\r\n", sizeof(int));
    
    // Configure I2C
    i2c.frequency(I2C_FREQUENCY);
    pc.printf("Master is working @ %dHz\r\n", I2C_FREQUENCY);
    pc.printf("Communicating with slave @ SLAVE_ADDRESS = 0x%x\r\n", SLAVE_ADDRESS);
    
    wait(5);
    
    // Perform diagnostic  
    pc.printf("Performing diagnostic\r\n");
    if (performDiagnostic()) {
        pc.printf("Diagnostic: memory passed test\r\n");
    } else {
        pc.printf("Diagnostic: memory failed test\r\n");
    }
    
    while(1) {
        aLED = 1;
        wait(0.2);
        aLED = 0;
        wait(0.2);
    }
}